package arraylist_demo;

/**
 * @brief Abstração de disciplina do programa.
 * @author andrea
 * @author alberto: Acrescentei exemplos de comentários Javadoc/Doxygen.
 */
public class Disciplina {

   /**
    * Inteiro que representa o primeiro semestre do ano.
    */
   public static final int PRIMEIRO = 1;
   /**
    * Inteiro que representa o segundo semestre do ano.
    */
   public static final int SEGUNDO = 2;

   private int ano;
   private int semestre;
   private String nome;
   private float nota;

   /**
    * Construtor padrão.
    */
   public Disciplina() {
   }

   /**
    * Constrói uma nova disciplina com os argumentos.
    *
    * @param ano Ano que cursou a disciplina.
    * @param semestre Semestre que a cursou a disciplina.
    * @param nome Nome da disciplina.
    * @param nota Nota final do aluno na disciplina.
    */
   public Disciplina(int ano, int semestre, String nome, float nota) {
      this.ano = ano;
      this.semestre = semestre;
      this.nome = nome;
      this.nota = nota;
   }

   /**
    * @return Ano que a disciplina foi cursada.
    */
   public int getAno() {
      return ano;
   }

   /**
    * Atualiza o ano da disciplina.
    *
    * @param ano Novo ano a ser considerado.
    */
   public void setAno(int ano) {
      this.ano = ano;
   }

   /**
    * @return Nome da disciplina.
    */
   public String getNome() {
      return nome;
   }

   /**
    * Define um novo nome para a disciplina.
    *
    * @param nome Novo nome a ser utilizado.
    */
   public void setNome(String nome) {
      this.nome = nome;
   }

   /**
    * @return Nota final do aluno na disciplina.
    */
   public float getNota() {
      return nota;
   }

   /**
    * Define a nota do aluno na disciplina.
    *
    * @param nota Nova nota a ser utilizada.
    */
   public void setNota(float nota) {
      this.nota = nota;
   }

   /**
    * @return Semestre em que a disciplina ocorreu.
    */
   public int getSemestre() {
      return semestre;
   }

   /**
    * Define o semestra que a disciplina ocorreu.
    *
    * @param semestre Novo semestra a ser considerado.
    */
   public void setSemestre(int semestre) {
      this.semestre = semestre;
   }

}
