package arraylist_demo;

class DisciplinaApp {

    public static void main(String args[]) {
        Disciplina d = new Disciplina(2011, Disciplina.PRIMEIRO, "Paradigmas", 9.5f);
        System.out.printf("Ano: %d, Semestre: %d, Nome: %s, Nota: %.2f\n",
                d.getAno(), d.getSemestre(),d.getNome(), d.getNota());
    }
}
